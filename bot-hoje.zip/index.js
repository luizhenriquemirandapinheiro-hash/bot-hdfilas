const { 
    Client, 
    GatewayIntentBits, 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    ChannelType, 
    PermissionFlagsBits,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
    REST,
    Routes,
    SlashCommandBuilder
} = require('discord.js');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMembers
    ]
});

const queues = {};
const matchConfirmations = {};

const slashCommands = [
    new SlashCommandBuilder()
        .setName('fila')
        .setDescription('Abre uma nova fila de aposta no canal.')
        .addStringOption(option =>
            option.setName('valor')
                .setDescription('Valor da partida (ex: 100,00)')
                .setRequired(false)
        )
].map(cmd => cmd.toJSON());

function buildButtons(channelName, queueId) {
    const is1v1 = channelName.toLowerCase().includes('1x1');

    let modeRow;
    if (is1v1) {
        modeRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`join_geloinf_${queueId}`).setLabel('Gelo Infinito').setStyle(ButtonStyle.Primary).setEmoji('🧊'),
            new ButtonBuilder().setCustomId(`join_gelonorm_${queueId}`).setLabel('Gelo Normal').setStyle(ButtonStyle.Success).setEmoji('✅')
        );
    } else {
        modeRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`join_normal_${queueId}`).setLabel('Normal').setStyle(ButtonStyle.Success).setEmoji('🟢'),
            new ButtonBuilder().setCustomId(`join_ump_${queueId}`).setLabel('Full Ump Xm8').setStyle(ButtonStyle.Primary).setEmoji('🔫')
        );
    }

    const leaveRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`leave_queue_${queueId}`).setLabel('Sair').setStyle(ButtonStyle.Danger).setEmoji('❌')
    );

    return [modeRow, leaveRow];
}

client.on('ready', async () => {
    console.log(`Bot online como ${client.user.tag}`);

    const rest = new REST({ version: '10' }).setToken("eyJhbGciOiJIUzI1NiJ9.eyJpZCI6IjQ2NTExMDU3MzczMDcyNjk4OTc5MTU2ODUiLCJrZXkiOiJhNWFmZjk0OTNjN2U4Y2ZlNjljMTZhYjMyNTdlIn0._RqBJzEoigMAtTWJmOGECIySp3moLQL13AvDH-R07Mo");
    try {
        await rest.put(
            Routes.applicationCommands(client.user.id),
            { body: slashCommands }
        );
        console.log('Comandos de barra (/) registrados com sucesso!');
    } catch (error) {
        console.error('Erro ao registrar Slash Commands:', error);
    }
});

client.on('interactionCreate', async (interaction) => {
    if (interaction.isChatInputCommand()) {
        if (interaction.commandName === 'fila') {
            const valor = interaction.options.getString('valor') || '100,00';
            const queueId = `${interaction.channel.id}_${Date.now()}`;
            const title = interaction.channel.name;

            const embed = new EmbedBuilder()
                .setTitle(`📱 • ${title.toUpperCase()} • R$ ${valor}`)
                .setColor('#8A2BE2')
                .setDescription(`**Jogadores na Fila (0/2):**\nNinguém na fila ainda.\n\nEscolha a sua preferência abaixo para entrar na fila:`);

            const rows = buildButtons(title, queueId);

            await interaction.reply({ embeds: [embed], components: rows });
        }
        return;
    }

    const { customId, user, guild, channel } = interaction;

    if (interaction.isStringSelectMenu()) {
        if (interaction.customId === 'mediador_options') {
            const selected = interaction.values[0];

            const isOwner = interaction.user.id === guild.ownerId;
            const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.Administrator);

            if (!isOwner && !isAdmin) {
                return interaction.reply({ content: '❌ Apenas o ADM ou Dono podem usar estas opções!', ephemeral: true });
            }

            if (selected === 'encerrar_fila') {
                await interaction.reply({ content: '🔒 **Fila encerrada pelo mediador.** Este canal será excluído em 20 segundos.' });
                setTimeout(() => { channel.delete().catch(() => {}); }, 20000);
            } else if (selected === 'alterar_valor') {
                await interaction.reply({ content: '✏️ Digite o novo valor da partida abaixo:', ephemeral: true });
            } else if (selected === 'definir_vencedor') {
                await interaction.reply({ content: '🏆 Escolha o vencedor marcando o usuário!', ephemeral: true });
            }
            return;
        }
    }

    if (!interaction.isButton()) return;

    if (customId.startsWith('leave_queue_')) {
        const queueId = customId.replace('leave_queue_', '');
        if (queues[queueId]) {
            const index = queues[queueId].players.findIndex(p => p.id === user.id);
            if (index !== -1) {
                queues[queueId].players.splice(index, 1);
                await updateQueueEmbed(queues[queueId].message, queues[queueId]);
            }
        }
        return interaction.deferUpdate().catch(() => {});
    }

    if (customId.startsWith('join_')) {
        const parts = customId.split('_');
        const modeType = parts[1];
        const queueId = parts.slice(2).join('_');

        let choiceLabel = 'Normal';
        if (modeType === 'geloinf') choiceLabel = 'Gelo Infinito';
        if (modeType === 'gelonorm') choiceLabel = 'Gelo Normal';
        if (modeType === 'normal') choiceLabel = 'Normal';
        if (modeType === 'ump') choiceLabel = 'Full Ump Xm8';

        if (!queues[queueId]) {
            queues[queueId] = {
                id: queueId,
                title: channel.name,
                maxPlayers: 2,
                players: [],
                message: interaction.message
            };
        }

        const queue = queues[queueId];
        const existingPlayer = queue.players.find(p => p.id === user.id);

        if (existingPlayer) {
            existingPlayer.choice = choiceLabel;
        } else {
            if (queue.players.length < queue.maxPlayers) {
                queue.players.push({ id: user.id, tag: user.username, choice: choiceLabel });
            }
        }

        await interaction.deferUpdate().catch(() => {});
        await updateQueueEmbed(interaction.message, queue);

        if (queue.players.length >= queue.maxPlayers) {
            const matchPlayers = [...queue.players];
            queue.players = []; 
            await updateQueueEmbed(interaction.message, queue);
            createPrivateMatchChannel(guild, matchPlayers, queue.title);
        }
    }

    if (customId.startsWith('confirm_match_') || customId.startsWith('cancel_match_')) {
        const matchId = customId.split('_').pop();
        const matchData = matchConfirmations[matchId];

        if (!matchData) return interaction.deferUpdate().catch(() => {});

        if (customId.startsWith('cancel_match_')) {
            await interaction.reply({ content: `❌ Partida cancelada por <@${user.id}>. Este canal será excluído em 20 segundos.` });
            delete matchConfirmations[matchId];
            setTimeout(() => { channel.delete().catch(() => {}); }, 20000);
            return;
        }

        if (customId.startsWith('confirm_match_')) {
            if (matchData.confirmed.includes(user.id)) {
                return interaction.reply({ content: '✅ Você já confirmou a partida! Aguarde o outro jogador.', ephemeral: true });
            }

            matchData.confirmed.push(user.id);
            await interaction.deferUpdate().catch(() => {});

            const remainingPlayer = matchData.players.find(p => !matchData.confirmed.includes(p.id));

            if (matchData.confirmed.length === 1) {
                const embed1 = new EmbedBuilder()
                    .setColor('#8A2BE2')
                    .setDescription(`✅ <@${user.id}> **confirmou a partida.**\n\n*Agora falta apenas <@${remainingPlayer.id}> para confirmar.*`);

                const members = await guild.members.fetch();
                const admMember = members.find(m => m.permissions.has(PermissionFlagsBits.Administrator) && !m.user.bot) || guild.members.cache.get(guild.ownerId);
                matchData.assignedAdm = admMember ? admMember.id : guild.ownerId;

                await channel.send({ 
                    content: `<@${matchData.assignedAdm}> a partida foi confirmada, assuma!`, 
                    embeds: [embed1] 
                });
            } 
            else if (matchData.confirmed.length >= 2) {
                if (matchData.initialMessage) {
                    await matchData.initialMessage.delete().catch(() => {});
                }

                const embed2 = new EmbedBuilder()
                    .setColor('#8A2BE2')
                    .setDescription(`✅ <@${user.id}> **confirmou a partida.**\n\n*Todos confirmaram! Partida iniciando...*`);

                await channel.send({ embeds: [embed2] });

                const embedPartida = new EmbedBuilder()
                    .setColor('#8A2BE2')
                    .addFields(
                        { name: 'Partida', value: `${matchData.title} R$ 1,00`, inline: false },
                        { name: 'Mediador', value: `<@${matchData.assignedAdm}>`, inline: false }
                    );

                const selectMenu = new ActionRowBuilder().addComponents(
                    new StringSelectMenuBuilder()
                        .setCustomId('mediador_options')
                        .setPlaceholder('[MEDIADOR] Selecione uma opção')
                        .addOptions(
                            new StringSelectMenuOptionBuilder().setLabel('Definir Vencedor').setValue('definir_vencedor').setEmoji('👑'),
                            new StringSelectMenuOptionBuilder().setLabel('Alterar Valor').setValue('alterar_valor').setEmoji('🔄'),
                            new StringSelectMenuOptionBuilder().setLabel('Encerrar Fila').setValue('encerrar_fila').setEmoji('❌')
                        )
                );

                const topMentions = `👁️ <@${matchData.players[0].id}> <@${matchData.players[1].id}> <@${matchData.assignedAdm}>`;

                await channel.send({ content: topMentions, embeds: [embedPartida], components: [selectMenu] });

                const embedMeet = new EmbedBuilder()
                    .setColor('#8A2BE2')
                    .setTitle('Caso peçam sua tela, faça o seguinte:')
                    .setDescription(
                        '__Instale o aplicativo google meet em seu celular.__\n' +
                        '→ **Android:** https://play.google.com/store/apps/details?id=com.google.android.apps.tachyon\n' +
                        '→ **Iphone:** https://apps.apple.com/br/app/google-meet/id1096918571\n' +
                        '→ **Emulador:** Não precisa instalar nada, apenas clique no link assim que enviado.\n\n' +
                        '**Após isto, veja o tutorial de como utilizar em :** #tutorial-tela'
                    );

                await channel.send({ embeds: [embedMeet] });

                const embedPix = new EmbedBuilder()
                    .setColor('#8A2BE2')
                    .setTitle('Pagamento via PIX')
                    .setImage('https://i.imgur.com/gK9J64X.png')
                    .setDescription(`**Chave PIX:** admfusionjoaovitor@gmail.com\n**Nome:** JOAO VITOR FUMIAN\n**Valor a ser pago:** \`R$ 1,50\``);

                await channel.send({ embeds: [embedPix] });
            }
        }
    }
});

async function updateQueueEmbed(message, queue) {
    const embed = new EmbedBuilder()
        .setTitle(`${message.embeds[0]?.title || queue.title}`)
        .setColor('#8A2BE2')
        .setDescription(`**Jogadores na Fila (${queue.players.length}/2):**\n` +
            (queue.players.length > 0 
                ? queue.players.map(p => `<@${p.id}> - Escolha: ${p.choice}`).join('\n')
                : 'Ninguém na fila ainda.\n\nEscolha a sua preferência abaixo para entrar na fila:'));

    const rows = buildButtons(queue.title, queue.id);
    await message.edit({ embeds: [embed], components: rows }).catch(() => {});
}

async function createPrivateMatchChannel(guild, players, title) {
    const matchId = Date.now().toString().slice(-5);
    
    const matchChannel = await guild.channels.create({
        name: `partida-${matchId}`,
        type: ChannelType.GuildText,
        permissionOverwrites: [
            { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
            ...players.map(p => ({ id: p.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] }))
        ]
    }).catch(() => null);

    if (!matchChannel) return;

    matchConfirmations[matchId] = { players: players, confirmed: [], title: title, initialMessage: null };
    const mentions = players.map(p => `<@${p.id}>`).join(' ');

    const embedMatch = new EmbedBuilder()
        .setTitle('Aguardando Confirmação')
        .setColor('#8A2BE2')
        .setDescription(`**${title}**\n\n**Capitães:**\n` + players.map((p, i) => `${i + 1}. <@${p.id}> (${p.choice})`).join('\n'));

    const rowMatch = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`confirm_match_${matchId}`).setLabel('Confirmar Partida').setStyle(ButtonStyle.Success).setEmoji('✅'),
        new ButtonBuilder().setCustomId(`cancel_match_${matchId}`).setLabel('Cancelar').setStyle(ButtonStyle.Danger).setEmoji('❌')
    );

    const initialMsg = await matchChannel.send({ content: mentions, embeds: [embedMatch], components: [rowMatch] });
    matchConfirmations[matchId].initialMessage = initialMsg;
}

client.login("eyJhbGciOiJIUzI1NiJ9.eyJpZCI6IjQ2NTExMDU3MzczMDcyNjk4OTc5MTU2ODUiLCJrZXkiOiJhNWFmZjk0OTNjN2U4Y2ZlNjljMTZhYjMyNTdlIn0._RqBJzEoigMAtTWJmOGECIySp3moLQL13AvDH-R07Mo");
